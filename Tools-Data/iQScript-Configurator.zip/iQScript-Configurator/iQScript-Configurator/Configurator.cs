﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace iQScript_Configurator
{
    class Configurator
    {
        Dictionary<Features, string> _features;
        MainWindow _mainWindow;
        public Configurator(MainWindow mainWindow)
        {
            _features = new Dictionary<Features, string>();
            _mainWindow = mainWindow;
        }

        // Tie each feature with its code snippet
        private void loadData()
        {
            StringReader reader = new StringReader(Resources.iQscript);
            Features feature = Features.Mandatory;
            string buffer = "";
            string temp;
            while (true)
            {
                temp = reader.ReadLine();
                if (temp == null)
                    break;
                if (temp.StartsWith(';'))
                {
                    _features.Add(feature, buffer);
                    buffer = "";
                    string featureString = temp.Substring(1, temp.IndexOf(" ") - 1);
                    feature = (Features)Enum.Parse(typeof(Features), featureString);
                    continue;
                }
                buffer += "\n" + temp;
            }
            _features.Add(feature, buffer);
        }

        public void install(string path, List<Features> featuresToInstall)
        {
            loadData();

            #region Directories Setup
            Directory.CreateDirectory(path);

            DirectoryInfo di;

            // Create CapsLock folder and save CapsLock.png to it
            if (featuresToInstall.Contains(Features.CapsLockFloat))
            {
                di = Directory.CreateDirectory(path + "\\Tools-Data\\CapsLock");
                Resources.CapsLock.Save(di.FullName + "\\CapsLock.png");
            }

            // Same but for NumPad\NumPad.png
            if (featuresToInstall.Contains(Features.NumPadHomerowFloat))
            {
                di = Directory.CreateDirectory(path + "\\Tools-Data\\NumPad");
                Resources.NumPad.Save(di.FullName + "\\NumPad.png");
            }

            // Create Scripts folder. We will store our scripts here.
            di = Directory.CreateDirectory(path + "\\Scripts");
            #endregion

            #region Main script file
            // Writes code for each feature the user wants to use.
            StreamWriter writer = new StreamWriter(path + "\\Scripts\\iQscript.txt");
            foreach(var snippet in _features)
            {
                if (featuresToInstall.Contains(snippet.Key))
                {
                    writer.WriteLine(snippet.Value);
                }
            }
            writer.Dispose();
            File.Delete(path + "\\Scripts\\iQscript.ahk");
            File.Move(path + "\\Scripts\\iQscript.txt", path + "\\Scripts\\iQscript.ahk");
            #endregion

            #region Other script files
            // Saves other script files
            if (featuresToInstall.Contains(Features.CapsLockFloat))
                File.WriteAllText(di.FullName + "\\iQcaps.ahk", Resources.iQcaps);

            if(featuresToInstall.Contains(Features.NumPadHomerowFloat))
                File.WriteAllText(di.FullName + "\\iQnumpad.ahk", Resources.iQnumpad);

            File.WriteAllText(di.FullName + "\\iQdialog.ahk", Resources.iQdialog);
            #endregion

            #region Shortcuts
            if (_mainWindow.getForm()._desktop)
                Desktop(path + "\\Scripts\\iQscript.ahk");

            if(_mainWindow.getForm()._startMenu)
                StartMenu(path + "\\Scripts\\iQscript.ahk");

            if (_mainWindow.getForm()._startup)
                Startup(path + "\\Scripts\\iQscript.ahk");
            #endregion
        }

        private void StartMenu(string pathToFile)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms);
            Directory.CreateDirectory(path + "\\iQScript");
            ShortcutTool.MakeShortcut(pathToFile, path + "\\iQScript\\iQscript.lnk", "iQScript");
        }
        private void Startup(string pathToFile)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup);
            ShortcutTool.MakeShortcut(pathToFile, path + "\\iQscript.lnk", "iQScript");
        }
        private void Desktop(string pathToFile)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            ShortcutTool.MakeShortcut(pathToFile, path + "\\iQscript.lnk", "iQScript");
        }

        public void uninstall(string path)
        {
            File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\iQscript.lnk");
            File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup) + "\\iQscript.lnk");

            emptyDir(new DirectoryInfo
                (Environment.GetFolderPath
                    (Environment.SpecialFolder.CommonPrograms)
                        + "\\iQScript"));

            emptyDir(new DirectoryInfo(path));
        }
        public void emptyDir(DirectoryInfo dir)
        {
            foreach (FileInfo file in dir.GetFiles())
                file.Delete();
            foreach (DirectoryInfo subdir in dir.GetDirectories())
                emptyDir(subdir);
            dir.Delete();
        }
    }
}
