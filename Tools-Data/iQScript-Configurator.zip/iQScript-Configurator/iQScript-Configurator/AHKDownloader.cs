﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iQScript_Configurator
{
    class AHKDownloader
    {
        // https://www.autohotkey.com/download/ahk-install.exe
    }
}
