﻿namespace iQScript_Configurator
{
    public enum Features
    {
        Mandatory,
        AltQClose,
        AltWMinimize,
        Alt8Del,
        Alt9Home,
        Alt0End,
        AltEExplorer,
        AltANotificationPanel,
        AltSScreenshot,
        LWinPowerToys,
        AltScrollHorizontalScroll,
        CapsLockFloat,
        NumPadHomerowFloat,
        SemiColonArrowSim
    }
}
